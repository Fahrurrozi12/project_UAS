<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ff8680"><b>Tentang Kami</b></h2>
	<p class="text-justify">Rapi Cake & Bakery adalah rantai toko roti di Indonesia terkemuka dengan 22 cabang (dapur pusat) yang mengelola 
		lebih dari 400 outlet di antaranya di: Jakarta, Surabaya, Malang, Bandung, Lampung, Yogyakarta, Bekasi, Depok, Medan, Makasar, Gorontalo,
		Denpasar, Solo, lamongan, Jember, Cikampek, Lombok, Dan masih banyak lainnya. Kami masih terus memperluas jangkauan kami ke tempat-tempat lain.</p>
<p>
Rapi Cake & Bakery  adalah salah satu pelopor pertama dalam bisnis roti modern di Indonesia. Didirikan pada tahun 1978, saat ini
 dikelola di bawah PT. Mustika Citra Rasa. Produk kami sehat, bergizi, dan terjangkau oleh semua orang.</p>
</div>




 <?php 
	include 'footer.php';
 ?>